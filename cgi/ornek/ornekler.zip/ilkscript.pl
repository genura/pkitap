#!/usr/bin/perl

print "Merhaba\n";
